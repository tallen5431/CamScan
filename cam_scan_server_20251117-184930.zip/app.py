# CamScan — Calibration Exporter (single-page viewer)
import os, base64, uuid, time
from flask import Flask, send_from_directory, url_for
from dash import Dash, html, dcc, Input, Output, State, no_update
import cv2, numpy as np

from calibration_core import calibrate_image, save_outputs

APP_PORT = int(os.getenv("PORT", "8059"))
APP_HOST = os.getenv("HOST", "0.0.0.0")
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")

# ---- Explicit load order for overlay JS modules (served by Dash from /assets) ----
ORDERED_SCRIPTS = [
    "/assets/calib.units.js",
    "/assets/calib.geometry.js",
    "/assets/calib.draw.js",
    "/assets/calib.annotations.js",
    "/assets/calib.export.js",
    "/assets/calib.viewport.js",
    "/assets/calib.gestures.js",
    "/assets/calib.ui.js",
    "/assets/calibrationOverlay.js",
]



def _resolve_edge_mm_from_env():
    v = os.getenv("CALIB_EDGE_MM")
    if not v:
        return None
    try:
        return float(v)
    except ValueError:
        print(f"[App] ⚠️ Invalid CALIB_EDGE_MM='{v}', ignoring.")
        return None

server = Flask(__name__)
app = Dash(
    __name__,
    server=server,
    suppress_callback_exceptions=True,
    external_scripts=ORDERED_SCRIPTS,  # guaranteed JS order
    assets_ignore=(
        r'.*\.ipynb_checkpoints.*'
        r'|calib\..*\.js'          # let ORDERED_SCRIPTS control all calib.* JS
        r'|calibrationOverlay\.js'  # avoid auto-loading overlay twice
    ),
)
app.title = "CamScan — Calibration Exporter"

# --- Force the uploader's <input type=file> to open the camera when possible ---
# Works on Android Chrome and most modern mobile browsers. iOS honors it on Safari if 'accept' is set.
app.index_string = """
<!DOCTYPE html>
<html>
  <head>
    {%metas%}
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
    <title>CamScan — Calibration Exporter</title>
    {%favicon%}
    {%css%}
    <style>
      /* Subtle mobile-friendly defaults */
      html,body{margin:0;padding:0;background:#0f0f10;color:#e6e6e6;font-family: Segoe UI, system-ui, sans-serif;}
      .container{max-width:1000px;margin:0 auto;padding:10px;}
      @media (max-width:768px){ .container{padding:8px;} }

      /* Scrollable wrapper for the viewer so tall images don't block the page */
      .cal-wrap{
        position: relative;
        height: 100dvh;             /* fill dynamic viewport height on mobile */
        overflow: auto;
        -webkit-overflow-scrolling: touch; /* iOS momentum scroll */
      }

      /* Keep toolbar visible while scrolling the image (matches JS styling) */
      .cal-toolbar{
        position: sticky;
        top: 0;
        z-index: 10;
        background: #111;
        padding-top: 6px;
        border-bottom: 1px solid #2a2a2a;
      }

      /* Make the upload zone a bit shorter on phones */
      @media (max-width:768px){
        #uploader{height:96px !important; line-height:96px !important;}
      }
    </style>
  </head>
  <body>
    <div class="container">
      {%app_entry%}
    </div>
    <footer>
      {%config%}
      {%scripts%}
      {%renderer%}
      <script>
        (function () {
          function patchCapture() {
            var host = document.getElementById('uploader');
            if (!host) return;
            var input = host.querySelector('input[type="file"]');
            if (!input) return;
            input.setAttribute('accept', 'image/*');
            input.setAttribute('capture', 'environment'); // prefer back camera
          }
          if (document.readyState !== 'loading') patchCapture();
          else document.addEventListener('DOMContentLoaded', patchCapture);
          new MutationObserver(patchCapture).observe(document.documentElement, {childList:true, subtree:true});
        })();
      </script>
    </footer>
  </body>
</html>
"""

def _decode_b64_image(contents: str):
    header, b64data = contents.split(",", 1)
    img_bytes = base64.b64decode(b64data)
    np_arr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    return img

app.layout = html.Div([
    html.Div([
        html.H2("📸 CamScan — Calibration Exporter"),
        dcc.Upload(
            id="uploader",
            children=html.Div(["Tap ", html.B("to snap a photo"), " or drop an image"]),
            multiple=False,
            style={
                "width":"100%","height":"120px","lineHeight":"120px","borderWidth":"2px",
                "borderStyle":"dashed","borderRadius":"8px","textAlign":"center","margin":"10px 0"
            },
            accept="image/*",  # important for iOS to allow camera
            # Note: Dash doesn't expose `capture`, so we set it via app.index_string above.
        ),
        html.Div(id="status", style={"margin":"8px 0"}),
    ], id="top-panel"),
    html.Div(id="viewer", style={"position":"relative"}),
    html.Div(id="cal-kpi", className="cal-kpi"),
    html.Div("", style={"height":"12px"})
], style={"maxWidth":"1000px","margin":"0 auto","fontFamily":"Segoe UI, sans-serif"})

@app.callback(
    Output("status","children"),
    Output("viewer","children"),
    Output("top-panel","style"),
    Input("uploader","contents"),
    State("uploader","filename"),
    prevent_initial_call=True
)
def on_upload(contents, filename):
    if not contents:
        return "⚠️ No file.", no_update, no_update

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    stem = os.path.splitext(filename or "image")[0]
    safe = "".join(c for c in stem if c.isalnum() or c in ("-","_")).strip("_") or "image"
    out_name = f"{safe}-{uuid.uuid4().hex[:8]}.jpg"

    img = _decode_b64_image(contents)
    cv2.imwrite(os.path.join(UPLOAD_DIR, out_name), img)

    edge_mm_env = _resolve_edge_mm_from_env()
    if edge_mm_env is not None:
        print(f"[App] Using CALIB_EDGE_MM from env: {edge_mm_env} mm")
    else:
        print("[App] No CALIB_EDGE_MM set; using calibration_core module default")

    cal, overlay = calibrate_image(img, edge_mm=edge_mm_env)
    json_path, _ = save_outputs(out_name, cal, overlay, UPLOAD_DIR)

    ts = int(time.time() * 1000)
    img_url_data = contents
    img_url_file = url_for("downloads", fname=out_name, v=ts)
    base, _ext = os.path.splitext(out_name)
    json_url = url_for("downloads", fname=f"{base}.calibration.json", v=ts)

    viewer = html.Div([
        html.Div([
            html.Div(id="cal-toolbar", className="cal-toolbar"),
            html.Canvas(id="cal-canvas", style={"display":"block", "margin":"0 auto"})
        ], id="cal-view", className="cal-view",
           **{
               "data-img": img_url_data,
               "data-img-fallback": img_url_file,
               "data-json": json_url
           },
           style={"textAlign":"center"})
    ], className="cal-wrap")

    marker_mm = cal.get("marker_size_mm", "—")
    status = (
        f"✅ Processed '{filename}' — {len(cal.get('markers',[]))} marker(s). "
        f"Marker size: {marker_mm} mm. Tap/click to annotate."
    )
    # Hide the header/uploader once we have an image so the viewer gets maximum vertical space
    return status, viewer, {"display": "none"}

@server.route("/uploads/<path:fname>")
def downloads(fname):
    return send_from_directory(UPLOAD_DIR, fname, as_attachment=False)

if __name__ == "__main__":
    app.run(host=APP_HOST, port=APP_PORT, debug=False)
